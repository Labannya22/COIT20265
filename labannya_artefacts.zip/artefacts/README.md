# My Work — Labannya Barua

Research and Data Engineering. Work packages 2.0 and 3.0.

This folder holds everything I built, written in plain language.

---

## Start here

| Document | What it covers |
|---|---|
| [`docs/DATA_ENGINEERING.md`](docs/DATA_ENGINEERING.md) | The UNSW-NB15 work: what I found, what I decided, why |
| [`docs/DECISIONS.md`](docs/DECISIONS.md) | Every decision that affects other people's work |

---

## The lab work

| Folder | What is in it |
|---|---|
| [`gns3/external_validation/`](gns3/external_validation/) | Attacks I ran from a separate laptop |
| [`gns3/data_processing/`](gns3/data_processing/) | Turning Zeek logs into model input |
| [`gns3/traffic/`](gns3/traffic/) | The combined dataset and test results |

---

## For the team report

[`report_sections/`](report_sections/) has sections 4.1, 4.3.4 and 4.3.7
rewritten in simpler language. Paste them straight in.

---

## The short version

**The problem.** Our models learn from a public dataset. They have to work on
traffic we make ourselves. The two do not look the same.

**What I did.** Found a set of 21 features that both sources can produce. Built
one pipeline so both are prepared identically. Generated attack traffic from a
separate laptop and pushed it through that pipeline into the models.

**Three things I found**

1. **42% of the training data is duplicated.** Removing duplicates *before*
   splitting matters. Doing it after would set the alert threshold using flows
   the model had already memorised.

2. **The best feature had to go.** `sttl` separates attacks better than anything
   else, but Zeek cannot produce it. It also works too well for a suspicious
   reason: the tool that made the dataset left distinctive TTL values in the
   attack traffic. A model using it learns that tool, not attacks.

3. **Thresholds do not travel.** Asking for a 1% false-alarm rate gave 2.13% on
   different data. The method is fine; the threshold has to be set on traffic
   that looks like what you are scoring. This changes the design: recalibration
   is something the system does regularly, not once.

**What is left.** Capture enough normal traffic in the lab to set the threshold
properly. Right now we only have 16 normal records, which is not enough to say
anything about false alarms.
