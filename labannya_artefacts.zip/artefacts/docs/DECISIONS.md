# Decisions

Decisions that affect what other people on the team use. Newest first.

Anything that changes what another workstream depends on goes here **before**
it is done, not after.

---

## 11 — Recalibration has to happen in the lab too

**Date:** September
**What:** The threshold must be set again on normal GNS3 traffic. We cannot
reuse the UNSW threshold.
**Why:** A 1% target gave 4.3–5.7% on the real test data. Different traffic,
different threshold.
**Affects:** Model workstream, dashboard

---

## 10 — Report practical results with a warning attached

**Date:** September
**What:** The false-alarm rates on the practical dataset are reported, but with
a note that they come from only 16 normal records.
**Why:** 10 false positives out of 16 is 62.5%, but as a rate from 16 samples it
means nothing. Reporting "625 false alerts per 1,000" without saying this would
be misleading.
**Affects:** Final report

---

## 9 — Scaling defect in the second dataset

**Date:** September
**What:** Eight of the 40 columns had values far outside the range of the rest.
One reached 4,294,952. I applied a log transform and rescaled, fitted on
training data only, and saved the settings.
**Why:** The autoencoder measures error by squaring differences. One column in
the millions would swamp everything else, and the anomaly score would describe
that one column instead of the whole flow.
**Affects:** Model workstream — the real fix belongs in the preparation script

---

## 8 — Explainability and severity belong to Sinha

**Date:** August
**What:** Confirmed after the task-leads table and the RACI matrix disagreed.
**Why:** The work distribution sheet gives Sinha the explanation view and the
severity logic.
**Affects:** Work packages 6.0 and 8.0

---

## 7 — Report the test set two ways

**Date:** August
**What:** Results are reported on both the official test set and a version with
the overlapping rows removed. Both are labelled.
**Why:** 1,337 normal test rows are identical to normal training rows. The
official figure is slightly optimistic. Better to show the gap than hide it.
**Affects:** Model workstream, final report

---

## 6 — Remove duplicates before splitting, not after

**Date:** August
**What:** Normal rows are deduplicated first, then split into training and
validation.
**Why:** 42% of the training data is duplicated. Splitting first would put
copies of the same flow on both sides, so the threshold would be set using flows
the model had already memorised.
**Affects:** All model work

---

## 5 — Keep the seven `ct_*` features even though they need code

**Date:** August
**What:** Kept, despite Zeek not providing them.
**Why:** Five of them are among the ten most useful portable features, and they
stay stable between the two data sources.
**Affects:** Lab workstream — the counting code must use the same window

---

## 4 — Drop all TTL and packet-level features

**Date:** August
**What:** 21 of 42 features excluded.
**Why:** Zeek's connection log has neither TTL nor packet-level detail. The
benchmark and the lab have to share one feature set.
**Cost:** `sttl`, the strongest feature in the dataset, is gone.
**Affects:** All model work

---

## 3 — Use the official partition, not the four raw CSVs

**Date:** August
**What:** Using `UNSW_NB15_training-set.csv` and `UNSW_NB15_testing-set.csv`.
**Why:** The raw files do not have the flow features already worked out.
**Affects:** Data preparation

---

## 2 — Drop `id` and `attack_cat` when loading

**Date:** August
**What:** Removed immediately. The label goes in a separate array.
**Why:** The data is sorted, so `id` gives away the answer. `attack_cat` is the
answer. Making leakage impossible is better than remembering to avoid it.
**Affects:** All model work

---

## 1 — One feature set for both data sources

**Date:** August
**What:** A feature only goes in if Zeek can produce it.
**Why:** If the models learn on 42 features and later receive 21, they do not
work. The proposal promises benchmark-to-lab validation, which needs one shared
set.
**Affects:** Everything downstream
