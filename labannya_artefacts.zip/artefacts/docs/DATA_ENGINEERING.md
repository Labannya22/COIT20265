# Data Engineering — What I Did

Labannya Barua. Work packages 2.0 and 3.0.

This explains the dataset work in plain terms: what I found, what I decided,
and why.

---

## 1. The problem I was solving

Our models learn from UNSW-NB15, a public dataset. But later they have to work
on traffic we create ourselves in the lab, which Zeek records.

These two sources do not look the same. UNSW-NB15 gives 42 ready-made features.
Zeek gives far fewer.

So my job was to find a set of features that works on **both**, and build one
pipeline that prepares data the same way for both.

---

## 2. Looking at the data first

Before changing anything, I checked what was actually in UNSW-NB15.

**Size**

| Partition | Rows | Columns |
|---|---|---|
| Training | 175,341 | 45 |
| Testing | 82,332 | 45 |

**What I found**

- **42% of training rows are duplicates.** 74,072 rows are exactly the same as
  another row, apart from the row number and the attack name. The test set has
  28,380 duplicates too.
- **1,193 normal test rows are copies of normal training rows.** That is 3.22%
  of the normal test data. Counting all rows, 8,541 test rows (10.37%) also
  appear in training.
- **No missing values.** Both partitions are complete.
- **No infinite values**, even though 2,657 rows have a duration of zero. The
  dataset authors already handled the division.
- **`state` has two values that only appear in the test set**: `ACC` and `CLO`.
  They are not in training at all.
- **`service` is `-` in 53.7% of rows.** This is not missing data. It means the
  service was not identified, so I kept it as its own category.
- **`proto` has 133 different values.** Three of them appear fewer than 50 times.

Every decision below comes from something in this list. I did not apply a
standard recipe.

---

## 3. Choosing the features

I checked every feature against one question: **can Zeek produce this?**

That left 21 features out of 42, in three groups.

**Read directly from Zeek**

`dur`, `spkts`, `dpkts`, `sbytes`, `dbytes`, `proto`, `service`

**Worked out from other fields**

`rate`, `sload`, `dload`, `smean`, `dmean`, `is_sm_ips_ports`

For example, `rate` is packets divided by duration.

**Have to be built with code**

The seven `ct_*` features. These count how many of the last 100 connections
share something — the same destination, the same service, and so on. Zeek does
not count these. I had to write the counting myself, using the same window as
the benchmark data.

**What I had to drop**

The strongest feature in the whole dataset is `sttl` — the time-to-live value.
Its effect size is 1.94, higher than anything else. The second strongest is
`ct_state_ttl` at 1.40.

Both need TTL. Zeek's connection log does not have a TTL field. So both had to go.

This costs us. But `sttl` works so well for a suspicious reason: the tool that
built UNSW-NB15 left distinctive TTL values in the attack traffic. A model using
it learns a fingerprint of that tool, not what an attack looks like. It would
not work on a real network.

I would rather report a lower number that means something.

---

## 4. Removing duplicates before splitting

This is the most important decision, and it is easy to get wrong.

The normal data is split two ways:

- 80% to train the models
- 20% to set the alert threshold

**If I split first, then removed duplicates**, copies of the same flow would end
up on both sides. The model would memorise a flow during training, then see the
same flow again when setting the threshold. It would score it as very normal.
The threshold would end up too low. Real traffic would then set off far more
alerts than we promised.

**So I removed duplicates first, then split.**

```
56,000 normal rows
   → remove duplicates → 51,331
   → split 80/20 → 41,065 training + 10,266 validation
```

Both orders produce working code. Neither gives an error. Only one gives a
threshold that holds on real traffic.

I did **not** remove duplicates from the test set. I kept two versions and
report results on both.

---

## 5. Preparing the numbers

**Dropped at load:** `id` and `attack_cat`.

The dataset is sorted with normal traffic first, so a low `id` means normal. The
model would learn the row number instead of the traffic. `attack_cat` is the
answer written out in words.

The label is kept in a separate array. It never touches the transformer. This
way, leaking the label is not something I have to remember to avoid — it is not
possible.

**log1p then RobustScaler for the numbers.**

The distributions are very lopsided. Most flows carry a few hundred bytes; a
few carry millions. `log1p` squashes the large values down. `RobustScaler` then
scales using the median and the middle 50%, so a handful of extreme values
cannot shift it.

I did not use `StandardScaler`, because it uses the mean and standard deviation,
and both move when there are outliers.

**One-hot encoding for `proto`, `service` and `state`.**

Models need numbers, not words. One-hot gives each value its own column.

I set `handle_unknown='ignore'`. This is not a precaution — the test set really
does contain `ACC` and `CLO`, which training never saw. Without this setting the
pipeline would crash.

Rare `proto` values are grouped into `other`, so we do not get 133 nearly-empty
columns.

**Result:** 21 features become 41 columns.

---

## 6. Saving the pipeline

Two files matter.

**`preprocessor.joblib`** holds the rules — which median, which scale, which
categories. Fitted on the training split only. Nothing else.

**`feature_order.json`** records the exact order of the 41 columns.

The second file prevents the worst kind of bug. When Zeek data arrives, the
columns might be in a different order. The model would then read `dur` where it
expects `sbytes`. It would not crash. It would just give confident, wrong
answers. Checking against this file catches that.

When laboratory data comes through, the transformer is **loaded, not refitted**.
Refitting on lab data would break the link between the two sources.

---

## 7. Checking it works

I ran an Isolation Forest with no tuning at all, just to see whether the reduced
feature set still separates normal from attack.

| Measure | Value |
|---|---|
| ROC-AUC | 0.795 |
| PR-AUC | 0.845 |

It works. Losing the strongest features did not break it. The other workstreams
could safely build on this.

---

## 8. A problem I found: thresholds do not travel

We set the threshold using the normal validation data, aiming for a 1%
false-alarm rate.

On the test data it gave **2.13%**. At a 3% target it gave 9.90%.

So I checked whether the method itself was broken. I set the threshold using the
test data directly instead:

| Target | Using validation data | Using test data |
|---|---|---|
| 0.5% | 0.70% | 0.50% |
| 1.0% | 2.13% | 1.01% |
| 3.0% | 9.90% | 3.01% |

The right column is almost exact. **The method is fine.** The problem is which
data you set the threshold on.

Why? Training and test normal traffic are genuinely different. A classifier can
tell them apart with AUC 0.641. Six of the 41 features shifted a lot, all of
them about traffic volume — `dload` shifted most.

**What this means for the project**

The false-alarm budget is not a promise. It only holds while the traffic looks
like the data the threshold was set on.

So in the lab, the threshold has to be set again using normal GNS3 traffic. We
cannot carry the UNSW threshold across. And recalibration has to be something
the system does regularly, not once during setup.

---

## 9. Files

| File | What it is |
|---|---|
| `profile_unsw.py` | Looks at the raw data, writes the quality report |
| `audit_duplicates.py` | Finds duplicates and overlap between partitions |
| `build_pipeline.py` | Builds and saves the preprocessing pipeline |
| `sanity_check.py` | Untuned baseline to confirm the features work |
| `shift_analysis.py` | Measures how training and test traffic differ |
| `preprocessor.joblib` | The saved transformer |
| `feature_order.json` | The 41 column names, in order |
| `feature_dictionary.csv` | Every feature, and where it comes from in Zeek |

Random seed is 42 everywhere. Package versions are pinned. Anyone can rerun
these from the raw CSV files and get the same numbers.
