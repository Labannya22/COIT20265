# Practical Traffic and Test Results

By Labannya Barua, with Syed Rubaiyat Karim.

The combined traffic we generated, and what happened when the trained models
scored it.

---

## What is in the dataset

3,047 Zeek connection records, from two sources.

| Source | Records | Who made it |
|---|---|---|
| Inside GNS3 | 1,416 | Arjita |
| From an external laptop | 1,631 | Me |

Each record keeps a note of where it came from and which scenario produced it,
so results can be broken down later.

**Important:** almost all of this is attack traffic. Only **16 records are
normal** — 12 internal and 4 external. This matters for how the results below
should be read.

---

## The models

Six models, all trained on UNSW-NB15 only, by Rubaiyat. None of them was
retrained on this data. My part was converting the traffic and running the
scoring.

| Model | ROC-AUC | PR-AUC | Recall |
|---|---|---|---|
| Hybrid IF + AE | 0.985 | 0.9999 | 0.999 |
| Isolation Forest | 0.984 | 0.9999 | 0.996 |
| Dense Autoencoder | 0.927 | 0.999 | 0.998 |
| One-Class SVM | 0.918 | 0.998 | 0.992 |
| Deep SVDD | 0.816 | 0.995 | 0.997 |
| LOF | 0.814 | 0.996 | 0.999 |

Recall is high across the board. The models find the attacks.

---

## Why the false-alarm rates cannot be trusted here

The false-positive rates come out between 43.75% and 93.75%. Those look alarming
and they should not be reported as they stand.

Here is why. Every model is judged against **16 normal records**.

| Model | Normal correct | Normal wrong | Rate shown |
|---|---|---|---|
| Isolation Forest | 8 | 8 | 50.00% |
| One-Class SVM | 9 | 7 | 43.75% |
| LOF | 6 | 10 | 62.50% |
| Deep SVDD | 1 | 15 | 93.75% |

Ten wrong out of sixteen is 62.5%. But as a **rate**, from 16 samples, it means
nothing. One record either way swings it by six percentage points.

The reported figure of "625 false alerts per 1,000 flows" is the same number
scaled up from 16 observations. It should not appear in the final report without
this explanation.

**What it actually tells us:** we need far more normal traffic from this
environment. That is the next task, not a finding about the models.

---

## The threshold problem

There is a second reason to be careful here.

These scores use the threshold set on UNSW-NB15 data. We already know thresholds
do not travel between data sources — on UNSW itself, a 1% target produced 4.3%
to 5.7% in practice.

Scoring lab traffic with a benchmark threshold gives a number we have already
shown cannot be relied on.

The threshold has to be set again using normal traffic captured from **this**
environment. Once we have enough of it.

---

## What comes next

1. Capture a decent amount of normal traffic in the lab
2. Set the threshold again using that traffic
3. Score the attacks against the new threshold
4. Then, and only then, report a false-alarm rate for the practical dataset

---

## Files here

| File | What it is |
|---|---|
| `combined_dataset.csv` | All 3,047 records with source and scenario labels |
| `model_scores.csv` | Every model's score for every record |
| `results_summary.md` | The tables above with full detail |
