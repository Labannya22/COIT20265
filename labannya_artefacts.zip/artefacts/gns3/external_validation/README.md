# External Attack Traffic

Attack traffic generated from a **separate physical laptop**, not from inside
the GNS3 lab.

By Labannya Barua, with Arjita Saha.

---

## Why use a second laptop

The lab already had a Kali attacker running inside GNS3. Adding one on separate
hardware means the traffic has to cross a real network boundary.

Traffic between two virtual machines on the same host can be handled inside the
hypervisor. It may never look the way it would on a real network. Going between
two physical machines gives flow records closer to what the system would
actually see in use.

---

## Setup

| Role | Machine | Address |
|---|---|---|
| Attacker | My laptop, Kali Linux | 192.168.4.52 |
| Target | Arjita's laptop, Ubuntu server in GNS3 | 192.168.10.20 |
| Sensor | Arjita's laptop, Zeek | passive, same network |

Arjita set up the environment, the server, the sensor and the routing between
the two networks. I ran the attacks.

---

## Check the connection first

Before generating anything I checked that my machine could reach the server.

This matters. If the logs came out empty afterwards, I would not know whether
the capture failed or the two machines were never connected. Checking first
removes that doubt.

The first attempt failed completely, 100% packet loss. A host on my own subnet
answered fine, which told us the fault was in the routing between the two
networks and not in either machine. Arjita fixed the routing and the ping worked.

Screenshots are in `../screenshots/`.

---

## What I ran

Five attack scenarios, all against our own server. Nothing outside the lab was
touched.

| Scenario | What it looks like | Zeek records |
|---|---|---|
| Nmap scan | Someone checking which ports are open | 1,004 |
| HTTP burst | The same web request over and over | 201 |
| DNS burst | The same DNS lookup over and over | 401 |
| SSH failed login | Repeated wrong passwords | 20 |
| ICMP burst | A flood of pings | 1 |
| Normal | Slow, ordinary traffic | 4 |
| **Total** | | **1,631** |

---

## About those numbers

These are **connection records, not packets**.

The ICMP burst sent 50 pings but shows as one record. Zeek groups a whole
conversation into a single line. That is how flow logging works, not a mistake.

Combined with Arjita's 1,416 internal records, the practical dataset has
**3,047 connection records**. Each one keeps a note of where it came from and
which scenario produced it.

---

## What this proved, and what it did not

**Proved.** Traffic from a separate machine goes through Zeek, through our
feature mapping, and into the format the models expect. Risks R-01 and R-06 in
our register are partly retired.

**Not proved yet.**

- Almost all of this is attack traffic. Only 4 normal records were captured.
  Without far more, no threshold can be set for this environment.
- A port scan is the easiest thing to detect. The harder case is telling a
  legitimate backup apart from data being stolen, and we have not run that yet.
- A scan makes short, failed connections. Features about large transfers were
  barely used, so their mapping is still unconfirmed.

---

## One limitation to be honest about

Our proposal says attacks run inside an isolated GNS3 network. This test ran
between two laptops over shared Wi-Fi.

Only our own server was targeted and the whole team knew about it, so nothing
went wrong. But the control we described was not fully in place. Later scenarios
should run inside the isolated topology.

---

## Files here

| File | What it is |
|---|---|
| `conn.log` | Zeek's record of the traffic |
| `commands.md` | The exact commands I ran |
| `../screenshots/` | Terminal output and Zeek logs |
