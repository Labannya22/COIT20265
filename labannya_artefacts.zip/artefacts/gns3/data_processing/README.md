# Turning Zeek Logs Into Model Input

By Labannya Barua.

Zeek records cannot go straight into the models. This folder holds the code that
converts them.

---

## The gap

Zeek's connection log has **13 usable fields**.

Our models expect **41 numbers, in a fixed order**.

Two steps sit in between.

```
Zeek conn.log  →  21 features  →  41 columns  →  models
   13 fields        (step 1)        (step 2)
```

---

## Step 1: 13 fields become 21 features

The 13 raw fields are basic connection facts: who talked to whom, on which
ports, using which protocol and service, for how long, and how many bytes and
packets went each way.

From these I build 21 features in three ways.

**Read straight across**

| Our feature | Zeek field |
|---|---|
| `dur` | `duration` |
| `spkts` | `orig_pkts` |
| `dpkts` | `resp_pkts` |
| `sbytes` | `orig_ip_bytes` |
| `dbytes` | `resp_ip_bytes` |
| `proto` | `proto` |
| `service` | `service` |

One trap here. Zeek has both `orig_bytes` and `orig_ip_bytes`. UNSW-NB15 counts
the headers, so **`orig_ip_bytes` is the correct one**. Using the wrong field
gives numbers that look fine but are consistently too small.

**Worked out with arithmetic**

| Our feature | How |
|---|---|
| `rate` | packets ÷ duration |
| `sload` | source bytes × 8 ÷ duration |
| `dload` | destination bytes × 8 ÷ duration |
| `smean` | source bytes ÷ source packets |
| `dmean` | destination bytes ÷ destination packets |
| `is_sm_ips_ports` | true if source and destination match |

Duration can be zero, so these need a guard or they produce infinity.

**Counted by us**

The seven `ct_*` features. Each one counts how many of the **last 100
connections** share something:

| Feature | Counts connections sharing |
|---|---|
| `ct_srv_src` | same service and same source |
| `ct_srv_dst` | same service and same destination |
| `ct_dst_ltm` | same destination |
| `ct_src_ltm` | same source |
| `ct_src_dport_ltm` | same source and destination port |
| `ct_dst_sport_ltm` | same destination and source port |
| `ct_dst_src_ltm` | same source and destination pair |

Zeek does not count these. We have to.

**This is the part most likely to go wrong.** The window has to be exactly the
same as the one used on the benchmark data. If one side counts over the last 100
connections and the other counts over the last 60, the same column means two
different things. Nothing errors. The results are just quietly wrong.

**One that does not map cleanly**

`state` and Zeek's `conn_state` describe the same idea with different words.
UNSW uses `FIN`, `CON`, `INT`. Zeek uses `SF`, `S0`, `REJ`, `RSTO`. We use a
lookup table, and some detail is lost in the translation.

---

## Step 2: 21 features become 41 columns

This uses the transformer saved when the benchmark data was prepared:
`preprocessor.joblib`.

It does three things:

1. `log1p` on the skewed numbers, to bring huge values down
2. `RobustScaler` to put everything on a comparable scale
3. One-hot encoding for `proto`, `service` and `state`

**The transformer is loaded, never refitted.**

Refitting on lab data would break the link between the two sources. The models
learned one representation; they have to be given the same one.

---

## Checking before scoring

Column order is the dangerous part. If the columns arrive in a different order,
the model reads `dur` where it expects `sbytes`. It does not crash. It returns
confident, wrong answers.

So there is a check that runs first:

- Are all 21 expected features present?
- Any nulls or infinities?
- Does the transformer accept the data?
- Do the 41 output columns match `feature_order.json` exactly?

If any of these fail, it stops. Better a loud failure than a quiet wrong answer.

---

## Files here

| File | What it does |
|---|---|
| `zeek_to_features.py` | Step 1, builds the 21 features |
| `verify_features.py` | The check described above |
| `features_21.csv` | Output of step 1 |
| `features_41.npz` | Output of step 2, ready for the models |
